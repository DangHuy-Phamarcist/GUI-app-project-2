﻿using System;
using System.Windows.Forms;

namespace CustomerRegistrationForm
{
    public partial class Form1 : Form
    {
        private int customerOrder = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // Get values from input fields
            string customerName = txtCustomerName.Text;
            string yearOfBirth = txtYearOfBirth.Text;
            string gender = txtGender.Text;
            string phoneNumber = txtPhoneNumber.Text;

            // Check if required fields are filled
            if (!string.IsNullOrEmpty(customerName) && !string.IsNullOrEmpty(phoneNumber))
            {
                // Increment the customer order for each registration
                customerOrder++;

                // Ensure customerOrder doesn't exceed 9999
                if (customerOrder > 9999)
                {
                    customerOrder = 1; // Reset to 1 if it exceeds 9999
                }

                // Generate the ID in format NDXXXX
                string customerID = $"ND{customerOrder:D4}"; // D4 pads the number to 4 digits

                // Display the generated ID in the label
                lblCustomerIDResult.Text = $"Trả kết quả > ID Khách Hàng: {customerID}";

                // Show a message box confirming registration
                MessageBox.Show($"Registration successful!\nYour customer ID is: {customerID}");

                // Optionally, you can reset the fields after registration
                ResetInputFields();
            }
            else
            {
                MessageBox.Show("Please fill in all required fields.");
            }
        }

        // Optional method to clear the input fields after registration
        private void ResetInputFields()
        {
            txtCustomerName.Clear();
            txtYearOfBirth.Clear();
            txtGender.Clear();
            txtPhoneNumber.Clear();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblCustomerIDResult_Click(object sender, EventArgs e)
        {

        }

        private void lblCustomerIDResult_Click_1(object sender, EventArgs e)
        {

        }
    }
}
